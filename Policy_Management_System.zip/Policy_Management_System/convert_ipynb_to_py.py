#!/usr/bin/env python
# coding: utf-8

# In[1]:


import nbformat
from nbconvert import PythonExporter
import os

# Path to the directory containing the notebooks
notebook_dir = "C:\\Users\\USER\\Policy_Management_System"

for file_name in os.listdir(notebook_dir):
    if file_name.endswith(".ipynb"):
        notebook_path = os.path.join(notebook_dir, file_name)
        with open(notebook_path, 'r', encoding='utf-8') as notebook_file:
            notebook_content = nbformat.read(notebook_file, as_version=4)
        
        # Convert to Python script
        python_exporter = PythonExporter()
        python_code, _ = python_exporter.from_notebook_node(notebook_content)
        
        # Save as .py
        script_file = file_name.replace(".ipynb", ".py")
        script_path = os.path.join(notebook_dir, script_file)
        with open(script_path, 'w', encoding='utf-8') as script_file:
            script_file.write(python_code)

        print(f"Converted {file_name} to {script_file.name}")

