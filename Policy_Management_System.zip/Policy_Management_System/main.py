#!/usr/bin/env python
# coding: utf-8

# In[77]:


from policyholders import Policyholder
from products import Product
from payments import Payment

try:
    # Create products
    product1 = Product(101, "Health Insurance", 100000)
    product2 = Product(102, "Life Insurance", 400000)
    product3 = Product(103, "House Insurance", 300000)
    product4 = Product(104, "Business Insurance", 250000)

    # Create policyholders
    policyholder1 = Policyholder(1, "Kemi", "kemi@yahoo.com")
    policyholder2 = Policyholder(2, "Modupe", "modupe@gmail.com")
    policyholder3 = Policyholder(3, "Dayo", "dayo@hotmail.com")

    print(' ')
    print('------Policyholders')
    
    # Register products for policyholders with error handling
    try:
        policyholder1.register_product(product1)
    except Exception as e:
        print(f"Error registering product for {policyholder1.name}: {e}")

    try:
        policyholder2.register_product(product2)
    except Exception as e:
        print(f"Error registering product for {policyholder2.name}: {e}")

    try:
        policyholder3.register_product(product3)
    except Exception as e:
        print(f"Error registering product for {policyholder3.name}: {e}")

    print(' ')
    print('------Payment Made By Policyholders')

    # Process payments with error handling
    try:
        payment1 = Payment(policyholder1, product1, 100000)
        payment1.process_payment()
    except Exception as e:
        print(f"Error processing payment for {policyholder1.name}: {e}")

    try:
        payment2 = Payment(policyholder2, product2, 400000)
        payment2.process_payment()
    except Exception as e:
        print(f"Error processing payment for {policyholder2.name}: {e}")

    try:
        payment3 = Payment(policyholder3, product3, 300000)
        payment3.process_payment()
    except Exception as e:
        print(f"Error processing payment for {policyholder3.name}: {e}")

    print(' ')
    print('------Account Details of Policyholder')

    # Display policyholder details
    try:
        policyholder1.display_details()
        policyholder2.display_details()
        policyholder3.display_details()
    except Exception as e:
        print(f"Error displaying account details: {e}")

    print(' ')
    print('------Account Status of Policyholder')

    # Suspend and reactivate a policyholder with error handling
    try:
        policyholder1.suspend()
        #policyholder1.reactivate()
    except Exception as e:
        print(f"Error modifying status for {policyholder1.name}: {e}")

    print(' ')
    print('------Payment Reminder')

    # Send a final reminder (should indicate the payment is complete) with error handling
    try:
        payment3.reminder()
    except Exception as e:
        print(f"Error sending final reminder for {policyholder3.name}: {e}")

    print(' ')
    print('------Register Policyholder after Suspension')

    # Register products for policyholders with error handling
    try:
        policyholder1.register_product(product1)
    except Exception as e:
        print(f"Error registering product for {policyholder1.name}: {e}")

except Exception as general_error:
    print(f"An error occurred in the policy management system: {general_error}")

