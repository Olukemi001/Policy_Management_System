#!/usr/bin/env python
# coding: utf-8

# In[3]:


class Payment:
    def __init__(self, policyholder, product, amount):
        try:
            if not hasattr(policyholder, 'name'):
                raise ValueError("Invalid policyholder. Policyholder must have a 'name' attribute.")
            if not hasattr(product, 'name'):
                raise ValueError("Invalid product. Product must have a 'name' attribute.")
            if not isinstance(amount, (int, float)) or amount <= 0:
                raise ValueError("Amount must be a positive number.")
            
            self.policyholder = policyholder
            self.product = product
            self.amount = amount
            self.is_paid = False
        except ValueError as e:
            print(f"Error initializing Payment: {e}")

    def process_payment(self):
        try:
            if self.is_paid:
                raise Exception(f"Payment has already been processed for {self.policyholder.name}.")
            
            self.is_paid = True
            print(f"Payment of {self.amount} for product {self.product.name} by {self.policyholder.name} processed.")
        except Exception as e:
            print(f"Error processing payment: {e}")

    def reminder(self):
        try:
            if not self.is_paid:
                print(f"Reminder: Payment of {self.amount} is due for {self.policyholder.name}.")
            else:
                print(f"Payment has already been made for {self.policyholder.name}.")
        except Exception as e:
            print(f"Error sending reminder: {e}")
    
    def apply_penalty(self, penalty_amount):
        try:
            if not isinstance(penalty_amount, (int, float)) or penalty_amount < 0:
                raise ValueError("Penalty amount must be a positive number.")
            if not self.is_paid:
                self.amount += penalty_amount
                print(f"Penalty of {penalty_amount} applied. Total due: {self.amount}")
            else:
                print(f"Payment is already completed. No penalty applied.")
        except ValueError as e:
            print(f"Error applying penalty: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")

