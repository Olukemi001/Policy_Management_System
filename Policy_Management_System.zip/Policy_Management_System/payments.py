#!/usr/bin/env python
# coding: utf-8

# In[7]:


# Define the Payment class to represent a payment transaction for a policyholder and product
class Payment:
    # Initialize the Payment object with the given details: policyholder, product, and amount
    def __init__(self, policyholder, product, amount):
        try:
            # Validate that the policyholder has a 'name' attribute
            if not hasattr(policyholder, 'name'):
                raise ValueError("Invalid policyholder. Policyholder must have a 'name' attribute.")
            
            # Validate that the product has a 'name' attribute
            if not hasattr(product, 'name'):
                raise ValueError("Invalid product. Product must have a 'name' attribute.")
            
            # Validate that the amount is a positive number (either integer or float)
            if not isinstance(amount, (int, float)) or amount <= 0:
                raise ValueError("Amount must be a positive number.")
            
            # Assign the validated input values to the object properties
            self.policyholder = policyholder
            self.product = product
            self.amount = amount
            self.is_paid = False  # Initially, the payment is not processed

        except ValueError as e:
            # Catch and display any validation errors that occur during initialization
            print(f"Error initializing Payment: {e}")

    # Method to process the payment for the product by the policyholder
    def process_payment(self):
        try:
            # Check if the payment has already been processed
            if self.is_paid:
                raise Exception(f"Payment has already been processed for {self.policyholder.name}.")
            
            # Mark the payment as processed
            self.is_paid = True
            print(f"Payment of {self.amount} for product {self.product.name} by {self.policyholder.name} processed.")
        
        except Exception as e:
            # Catch and display any errors that occur during payment processing
            print(f"Error processing payment: {e}")

    # Method to send a payment reminder if the payment is not completed
    def reminder(self):
        try:
            # If the payment has not been made, send a reminder
            if not self.is_paid:
                print(f"Reminder: Payment of {self.amount} is due for {self.policyholder.name}.")
            else:
                # If the payment has already been made, notify the user
                print(f"Payment has already been made for {self.policyholder.name}.")
        
        except Exception as e:
            # Catch and display any errors that occur while sending the reminder
            print(f"Error sending reminder: {e}")
    
    # Method to apply a penalty for overdue payment
    def apply_penalty(self, penalty_amount):
        try:
            # Validate that the penalty amount is a positive number
            if not isinstance(penalty_amount, (int, float)) or penalty_amount < 0:
                raise ValueError("Penalty amount must be a positive number.")
            
            # If the payment is not completed, apply the penalty
            if not self.is_paid:
                self.amount += penalty_amount  # Increase the total amount due
                print(f"Penalty of {penalty_amount} applied. Total due: {self.amount}")
            else:
                # If the payment has been completed, no penalty is applied
                print(f"Payment is already completed. No penalty applied.")
        
        except ValueError as e:
            # Catch and display any validation errors related to the penalty amount
            print(f"Error applying penalty: {e}")
        
        except Exception as e:
            # Catch and display any unexpected errors that occur during penalty application
            print(f"Unexpected error: {e}")


