#!/usr/bin/env python
# coding: utf-8

# In[7]:


# Define the Policyholder class to represent a policyholder in the system
class Policyholder:
    # Initialize the Policyholder object with the given details: ID, name, and email
    def __init__(self, policyholder_id, name, email):
        try:
            # Validate that policyholder_id is an integer
            if not isinstance(policyholder_id, int):
                raise ValueError("Policyholder ID must be an integer.")
            
            # Validate that name is a non-empty string
            if not name or not isinstance(name, str):
                raise ValueError("Name must be a non-empty string.")
            
            # Validate that email is a valid email address (must contain '@')
            if not email or "@" not in email:
                raise ValueError("Email must be a valid email address.")
            
            # Assign the validated input values to the object properties
            self.policyholder_id = policyholder_id
            self.name = name
            self.email = email
            self.is_active = True  # Assume the policyholder is active by default
            self.products = []  # Empty list to hold products registered by the policyholder

        except ValueError as e:
            # Catch and display any validation errors that occur during initialization
            print(f"Error initializing Policyholder: {e}")

    # Method to register a product for the policyholder
    def register_product(self, product):
        try:
            # Ensure the product has a 'name' attribute (i.e., a valid product)
            if not hasattr(product, 'name'):
                raise AttributeError("Invalid product. Product must have a 'name' attribute.")
            
            # If the policyholder is active, register the product
            if self.is_active:
                self.products.append(product)
                print(f"{self.name} registered for product: {product.name}")
            else:
                # If the policyholder is suspended, prevent registration
                print(f"Cannot register. Policyholder {self.name} is suspended.")
        
        except AttributeError as e:
            # Catch and display any errors related to the product validation
            print(f"Error registering product: {e}")

    # Method to suspend the policyholder's account
    def suspend(self):
        if self.is_active:
            self.is_active = False  # Mark the policyholder as inactive
            print(f"Policyholder {self.name} has been suspended.")
        else:
            # If the policyholder is already suspended, notify the user
            print(f"Policyholder {self.name} is already suspended.")

    # Method to reactivate a suspended policyholder's account
    def reactivate(self):
        if not self.is_active:
            self.is_active = True  # Mark the policyholder as active again
            print(f"Policyholder {self.name} has been reactivated.")
        else:
            # If the policyholder is already active, notify the user
            print(f"Policyholder {self.name} is already active.")

    # Method to display the details of the policyholder
    def display_details(self):
        try:
            # Determine the status based on whether the policyholder is active
            status = "Active" if self.is_active else "Suspended"
            
            # If no products are registered, display a message indicating so
            if not self.products:
                product_list = "No products registered."
            else:
                # Create a formatted list of product names
                product_list = ", ".join(f"- {product.name}" for product in self.products)
            
            # Print the policyholder details including ID, name, status, and registered products
            print(f"Policyholder ID: {self.policyholder_id}, Name: {self.name}, "
                  f"Status: {status}, Registered Products: {product_list}")
        
        except Exception as e:
            # Catch and display any unexpected errors while displaying details
            print(f"Error displaying details: {e}")

