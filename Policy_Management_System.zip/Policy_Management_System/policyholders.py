#!/usr/bin/env python
# coding: utf-8

# In[1]:


class Policyholder:
    def __init__(self, policyholder_id, name, email):
        try:
            if not isinstance(policyholder_id, int):
                raise ValueError("Policyholder ID must be an integer.")
            if not name or not isinstance(name, str):
                raise ValueError("Name must be a non-empty string.")
            if not email or "@" not in email:
                raise ValueError("Email must be a valid email address.")
            
            self.policyholder_id = policyholder_id
            self.name = name
            self.email = email
            self.is_active = True
            self.products = []
        except ValueError as e:
            print(f"Error initializing Policyholder: {e}")

    def register_product(self, product):
        try:
            if not hasattr(product, 'name'):
                raise AttributeError("Invalid product. Product must have a 'name' attribute.")
            
            if self.is_active:
                self.products.append(product)
                print(f"{self.name} registered for product: {product.name}")
            else:
                print(f"Cannot register. Policyholder {self.name} is suspended.")
        except AttributeError as e:
            print(f"Error registering product: {e}")

    def suspend(self):
        if self.is_active:
            self.is_active = False
            print(f"Policyholder {self.name} has been suspended.")
        else:
            print(f"Policyholder {self.name} is already suspended.")

    def reactivate(self):
        if not self.is_active:
            self.is_active = True
            print(f"Policyholder {self.name} has been reactivated.")
        else:
            print(f"Policyholder {self.name} is already active.")

    def display_details(self):
        try:
            status = "Active" if self.is_active else "Suspended"
            if not self.products:
                product_list = "No products registered."
            else:
                product_list = ", ".join(f"- {product.name}" for product in self.products)
            
            print(f"Policyholder ID: {self.policyholder_id}, Name: {self.name}, "
                  f"Status: {status}, Registered Products: {product_list}")
        except Exception as e:
            print(f"Error displaying details: {e}")

