#!/usr/bin/env python
# coding: utf-8

# In[3]:


class Product:
    def __init__(self, product_id, name, premium):
        try:
            if not isinstance(product_id, int):
                raise ValueError("Product ID must be an integer.")
            if not name or not isinstance(name, str):
                raise ValueError("Product name must be a non-empty string.")
            if not isinstance(premium, (int, float)) or premium <= 0:
                raise ValueError("Premium must be a positive number.")
            
            self.product_id = product_id
            self.name = name
            self.premium = premium
            self.is_active = True
        except ValueError as e:
            print(f"Error initializing Product: {e}")

    def update_details(self, name=None, premium=None):
        try:
            if name is not None:
                if not isinstance(name, str) or not name.strip():
                    raise ValueError("Name must be a non-empty string.")
                self.name = name
            if premium is not None:
                if not isinstance(premium, (int, float)) or premium <= 0:
                    raise ValueError("Premium must be a positive number.")
                self.premium = premium
            
            print(f"Product {self.product_id} updated: Name - {self.name}, Premium - {self.premium}")
        except ValueError as e:
            print(f"Error updating Product details: {e}")

    def suspend(self):
        try:
            if not self.is_active:
                print(f"Product {self.name} is already suspended.")
            else:
                self.is_active = False
                print(f"Product {self.name} has been suspended.")
        except Exception as e:
            print(f"Error suspending Product: {e}")

