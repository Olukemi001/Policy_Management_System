#!/usr/bin/env python
# coding: utf-8

# In[7]:


# Define the Product class to represent a product in the system
class Product:
    # Initialize the Product object with the given details: ID, name, and premium
    def __init__(self, product_id, name, premium):
        try:
            # Validate that product_id is an integer
            if not isinstance(product_id, int):
                raise ValueError("Product ID must be an integer.")
            
            # Validate that name is a non-empty string
            if not name or not isinstance(name, str):
                raise ValueError("Product name must be a non-empty string.")
            
            # Validate that premium is a positive number (either integer or float)
            if not isinstance(premium, (int, float)) or premium <= 0:
                raise ValueError("Premium must be a positive number.")
            
            # Assign the validated input values to the object properties
            self.product_id = product_id
            self.name = name
            self.premium = premium
            self.is_active = True  # Assume the product is active by default

        except ValueError as e:
            # Catch and display any validation errors that occur during initialization
            print(f"Error initializing Product: {e}")

    # Method to update the product details (name and/or premium)
    def update_details(self, name=None, premium=None):
        try:
            # If a new name is provided, validate and update the product's name
            if name is not None:
                if not isinstance(name, str) or not name.strip():
                    raise ValueError("Name must be a non-empty string.")
                self.name = name
            
            # If a new premium is provided, validate and update the product's premium
            if premium is not None:
                if not isinstance(premium, (int, float)) or premium <= 0:
                    raise ValueError("Premium must be a positive number.")
                self.premium = premium
            
            # Print confirmation that the product's details have been updated
            print(f"Product {self.product_id} updated: Name - {self.name}, Premium - {self.premium}")
        
        except ValueError as e:
            # Catch and display any validation errors that occur during the update
            print(f"Error updating Product details: {e}")

    # Method to suspend the product, marking it as inactive
    def suspend(self):
        try:
            # If the product is already suspended, notify the user
            if not self.is_active:
                print(f"Product {self.name} is already suspended.")
            else:
                # Suspend the product by setting it to inactive
                self.is_active = False
                print(f"Product {self.name} has been suspended.")
        
        except Exception as e:
            # Catch and display any unexpected errors that occur while suspending the product
            print(f"Error suspending Product: {e}")

